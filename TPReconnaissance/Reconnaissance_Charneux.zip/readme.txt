Ce TP a été réaliser par Dimitri Charneux

Tout le TP a été fait et il fonctionne.

Les textes "papa", "maman", et "mer" sont très bien reconnus.
Les crochets, les accolades, les triangles, les cerlces et les rectangles sont aussi bien reconnus.
Le delete est parfois confondu avec un triangle quand il n'est pas très bien dessiné.
Il faut aussi faire attention en dessinant le 'v' et le check.
Enfin, pour le 'x', il est bien reconnu quand nous commençons à le dessiner par le très du haut mais pas quand on commence par celui du bas.

Le jar doit être dans le même dossier que le gesture.xml pour fonctionner.
